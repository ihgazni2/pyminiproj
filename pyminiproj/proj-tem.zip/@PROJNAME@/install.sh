git add .
git commit -m $1
python3 setup.py install --record install.txt

