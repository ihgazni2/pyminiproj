import sys
import os
import argparse
import pkg_resources

import @projname@ 



def main():
    print("command line bin of @projname@ !!")
