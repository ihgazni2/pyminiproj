.. contents:: Table of Contents
   :depth: 5


*@projname@*
------------



Installation
============

    ::
    
        $ pip3 install @projname@

Usage
=====
    
    ::
        

        

License
=======

- MIT
